# Tu primera red neuronal
Este codigo, actualizado al 4 de marzo de 2021, sirve como soporte para el video "Tu primera red neuronal": 
https://youtu.be/UNFFLJPW7KQ

Si deja de funcionar por algun motivo, deja un issue en github o un comentario en el video

Ya no es necesario bajar la libreria jscolor, ya viene como parte del codigo usando un CDN :)